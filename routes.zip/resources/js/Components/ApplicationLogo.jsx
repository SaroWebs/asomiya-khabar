export default function ApplicationLogo(props) {
    return (
        <img src="/static/images/logox.png" alt="" {...props}/>
    );
}
