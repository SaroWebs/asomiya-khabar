import MasterLayout from '@/Layouts/MasterLayout'
import React from 'react'

const Test = (props) => {
 
  return (
    <MasterLayout {...props}>
        test
    </MasterLayout>
  )
}

export default Test