import React from 'react'

const index = (props) => {
  return (
	<div>index</div>
  )
}

export default index